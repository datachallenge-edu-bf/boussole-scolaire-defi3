import json, csv, heapq, numpy as np, unicodedata
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
from matplotlib.colors import BoundaryNorm, ListedColormap
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':10})
def norm(s): return ''.join(c for c in unicodedata.normalize('NFD',s.upper()) if unicodedata.category(c)!='Mn').replace('LES ','').replace('KOURITTENGA','KOURITENGA').replace('KOMONDJARI','KOMONJDJARI')
rows=list(csv.DictReader(open('provinces.csv')))
D={norm(r['province']):r for r in rows}
gj=json.load(open('/home/claude/geo/bfa_ADM2.geojson'))
gr=json.load(open('/home/claude/geo/bfa_ADM1.geojson'))
E=np.array([int(r['eleves']) for r in rows]); M=np.array([int(r['maitres']) for r in rows])
nat=E.sum()/M.sum()
def polys(geom):
    cs=geom['coordinates']
    if geom['type']=='Polygon': cs=[cs]
    return [np.array(p[0]) for p in cs]
# ---------- Figure 1: map REM by province
bounds=[0,45,50,55,60,70,110]
cols=['#cfdbe8','#9fb3c9','#e9c46a','#f4a261','#e76f51','#9b2226']
cmap=ListedColormap(cols); bn=BoundaryNorm(bounds,cmap.N)
fig,ax=plt.subplots(figsize=(6.4,4.9),dpi=300)
for f in gj['features']:
    k=norm(f['properties']['shapeName']); r=D[k]; rem=float(r['rem'])
    for p in polys(f['geometry']):
        ax.add_patch(Polygon(p,closed=True,facecolor=cmap(bn(rem)),edgecolor='white',lw=0.5))
for f in gr['features']:
    for p in polys(f['geometry']):
        ax.add_patch(Polygon(p,closed=True,fill=False,edgecolor='#333333',lw=0.9))
lab={'LOROUM':(0,0),'YAGHA':(0,0),'SENO':(0,0),'KOMPIENGA':(0,0),'BAM':(0,0),'KADIOGO':(0,0),'NOUMBIEL':(0,0),'SANMATENGA':(0,0)}
for f in gj['features']:
    k=norm(f['properties']['shapeName'])
    if k in lab:
        ps=polys(f['geometry']); p=max(ps,key=len); c=p.mean(0)
        name=f['properties']['shapeName'].replace('Seno','Séno')
        off={'LOROUM':(0.05,0.12),'SANMATENGA':(0.05,-0.05),'BAM':(-0.02,0.02)}.get(k,(0,0))
        ax.annotate(f"{name}\n{float(D[k]['rem']):.1f}".replace('.',','),(c[0]+off[0],c[1]+off[1]),ha='center',va='center',fontsize=6.3,color='black',fontweight='bold',path_effects=[pe.withStroke(linewidth=2.2,foreground='white')])
ax.set_xlim(-5.65,2.5); ax.set_ylim(9.3,15.2); ax.set_aspect('equal'); ax.axis('off')
from matplotlib.patches import Patch
labs=['< 45','45 à 50','50 à 55','55 à 60','60 à 70','≥ 70']
ax.legend([Patch(fc=c,ec='white') for c in cols],labs,title='Élèves par maître',loc='lower right',fontsize=7,title_fontsize=7.5,frameon=False)
plt.tight_layout(pad=0.1); plt.savefig('figures/fig_carte_rem.png',bbox_inches='tight'); plt.close()

# ---------- Figure 2: prorata vs optimised with N=1000
N=1000
Mp=M+N*M/M.sum()
Mg=M.astype(float).copy(); h=[(-E[i]/Mg[i],i) for i in range(len(E))]; heapq.heapify(h)
for _ in range(N):
    v,i=heapq.heappop(h); Mg[i]+=1; heapq.heappush(h,(-E[i]/Mg[i],i))
rem0=E/M; idx=[i for i in np.argsort(-rem0) if rem0[i]>60]
names=[rows[i]['province'].title().replace('Les Bale','Balé').replace('Seno','Séno').replace('Kossi','Kossi') for i in idx]
fig,ax=plt.subplots(figsize=(6.4,3.6),dpi=300)
y=np.arange(len(idx))[::-1]
for yy,i in zip(y,idx):
    ax.plot([E[i]/Mg[i],rem0[i]],[yy,yy],color='#c9c9c9',lw=2,zorder=1)
ax.scatter(rem0[idx],y,s=34,color='#9b2226',zorder=3,label='Situation 2024-2025')
ax.scatter((E/Mp)[idx],y+0.18,s=22,marker='s',color='#9fb3c9',zorder=2,label='+1\u202f000 enseignants au prorata')
ax.scatter((E/Mg)[idx],y,s=34,color='#1f3a5f',zorder=3,label='+1\u202f000 enseignants, répartition optimisée')
for yy,i in zip(y,idx):
    ax.text(E[i]/Mg[i]-1.2,yy,f"+{int(Mg[i]-M[i])}",ha='right',va='center',fontsize=7,color='#1f3a5f')
ax.axvline(60,ls='--',color='#555',lw=0.9); ax.text(60.4,len(idx)-0.35,'Seuil de 60',fontsize=7.5,color='#555')
ax.axvline(nat,ls=':',color='#888',lw=0.9); ax.text(nat-0.4,len(idx)-0.35,'Moyenne\nnationale : 50,9',fontsize=7,color='#666',ha='right',va='center')
ax.set_yticks(y); ax.set_yticklabels(names,fontsize=8.5)
ax.set_xlabel('Élèves par maître',fontsize=9); ax.set_xlim(38,104)
for s in ('top','right','left'): ax.spines[s].set_visible(False)
ax.tick_params(axis='y',length=0); ax.grid(axis='x',color='#eee'); ax.set_axisbelow(True)
ax.legend(fontsize=7.3,frameon=False,loc='lower right')
plt.tight_layout(pad=0.2); plt.savefig('figures/fig_allocation.png',bbox_inches='tight'); plt.close()
print('done', [(n, round(rem0[i],1), round((E/Mp)[i],1), round((E/Mg)[i],1), int(Mg[i]-M[i])) for n,i in zip(names,idx)])
